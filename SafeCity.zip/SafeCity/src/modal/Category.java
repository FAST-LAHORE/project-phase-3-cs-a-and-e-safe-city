/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modal;

/**
 *
 * @author wmall
 */
public enum Category {
   Ambulance,FireBrigade,Kidnapping,Murder,LostPerson,Suicide,Theft,Other
}
