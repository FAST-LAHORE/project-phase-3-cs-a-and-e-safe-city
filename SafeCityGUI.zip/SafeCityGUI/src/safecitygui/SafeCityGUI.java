package safecitygui;

public class SafeCityGUI {
    
    public static void main(String[] args) {
        
    }
}
