package safecitygui;

import java.awt.Color;
import javax.swing.JPanel;

public class MainPage extends javax.swing.JFrame {
    
    public MainPage() {
        initComponents();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainPanel = new javax.swing.JPanel();
        LeftPanel = new javax.swing.JPanel();
        RescuePortal = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        PublicPortal = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        PolicePortal = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        EmployeePortal = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        RightPanel = new javax.swing.JPanel();
        LoginPanel = new javax.swing.JPanel();
        LoginHeader = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        IDField = new javax.swing.JTextField();
        PassField = new javax.swing.JPasswordField();
        LoginBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setResizable(false);

        MainPanel.setBackground(new java.awt.Color(255, 255, 204));

        LeftPanel.setBackground(new java.awt.Color(54, 33, 89));
        LeftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        RescuePortal.setBackground(new java.awt.Color(59, 40, 97));
        RescuePortal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RescuePortalMouseClicked(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/safecitygui/Images/rescue_icon.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2.setText("Rescue Portal");

        javax.swing.GroupLayout RescuePortalLayout = new javax.swing.GroupLayout(RescuePortal);
        RescuePortal.setLayout(RescuePortalLayout);
        RescuePortalLayout.setHorizontalGroup(
            RescuePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RescuePortalLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        RescuePortalLayout.setVerticalGroup(
            RescuePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RescuePortalLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(RescuePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                .addContainerGap())
        );

        LeftPanel.add(RescuePortal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 260, 50));

        PublicPortal.setBackground(new java.awt.Color(59, 40, 97));
        PublicPortal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PublicPortalMouseClicked(evt);
            }
        });

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/safecitygui/Images/public_icon.png"))); // NOI18N

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("Public Portal");

        javax.swing.GroupLayout PublicPortalLayout = new javax.swing.GroupLayout(PublicPortal);
        PublicPortal.setLayout(PublicPortalLayout);
        PublicPortalLayout.setHorizontalGroup(
            PublicPortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PublicPortalLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        PublicPortalLayout.setVerticalGroup(
            PublicPortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PublicPortalLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PublicPortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        LeftPanel.add(PublicPortal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 260, 50));

        PolicePortal.setBackground(new java.awt.Color(59, 40, 97));
        PolicePortal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PolicePortalMouseClicked(evt);
            }
        });

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/safecitygui/Images/police_icon.png"))); // NOI18N

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 204, 204));
        jLabel6.setText("Police Portal");

        javax.swing.GroupLayout PolicePortalLayout = new javax.swing.GroupLayout(PolicePortal);
        PolicePortal.setLayout(PolicePortalLayout);
        PolicePortalLayout.setHorizontalGroup(
            PolicePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PolicePortalLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        PolicePortalLayout.setVerticalGroup(
            PolicePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PolicePortalLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PolicePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                .addContainerGap())
        );

        LeftPanel.add(PolicePortal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 260, 50));

        jLabel7.setFont(new java.awt.Font("Azonix", 2, 34)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("SafeCity");
        LeftPanel.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 200, 70));

        EmployeePortal.setBackground(new java.awt.Color(85, 85, 118));
        EmployeePortal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EmployeePortalMouseClicked(evt);
            }
        });

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/safecitygui/Images/employee_icon.png"))); // NOI18N

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("Employee Portal");

        javax.swing.GroupLayout EmployeePortalLayout = new javax.swing.GroupLayout(EmployeePortal);
        EmployeePortal.setLayout(EmployeePortalLayout);
        EmployeePortalLayout.setHorizontalGroup(
            EmployeePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EmployeePortalLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );
        EmployeePortalLayout.setVerticalGroup(
            EmployeePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EmployeePortalLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(EmployeePortalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        LeftPanel.add(EmployeePortal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 260, 50));
        LeftPanel.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, 200, 30));

        RightPanel.setBackground(new java.awt.Color(255, 255, 204));

        LoginPanel.setBackground(new java.awt.Color(255, 255, 204));
        LoginPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LoginHeader.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        LoginHeader.setForeground(new java.awt.Color(54, 33, 89));
        LoginHeader.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LoginHeader.setText("L O G I N");
        LoginPanel.add(LoginHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 400, 90));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/safecitygui/Images/password_icon.png"))); // NOI18N
        LoginPanel.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 130, 30));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/safecitygui/Images/email_icon.png"))); // NOI18N
        LoginPanel.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 130, 30));

        IDField.setBackground(new java.awt.Color(54, 33, 89));
        IDField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        IDField.setForeground(new java.awt.Color(255, 255, 204));
        IDField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        IDField.setText("ID");
        LoginPanel.add(IDField, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 220, 30));

        PassField.setBackground(new java.awt.Color(54, 33, 89));
        PassField.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        PassField.setForeground(new java.awt.Color(255, 255, 204));
        PassField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PassField.setText("Password");
        LoginPanel.add(PassField, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 220, 30));

        LoginBtn.setBackground(new java.awt.Color(54, 33, 89));
        LoginBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        LoginBtn.setForeground(new java.awt.Color(255, 255, 204));
        LoginBtn.setText("Login");
        LoginBtn.setInheritsPopupMenu(true);
        LoginBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginBtnActionPerformed(evt);
            }
        });
        LoginPanel.add(LoginBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 320, 120, 40));

        javax.swing.GroupLayout RightPanelLayout = new javax.swing.GroupLayout(RightPanel);
        RightPanel.setLayout(RightPanelLayout);
        RightPanelLayout.setHorizontalGroup(
            RightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LoginPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
        );
        RightPanelLayout.setVerticalGroup(
            RightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LoginPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout MainPanelLayout = new javax.swing.GroupLayout(MainPanel);
        MainPanel.setLayout(MainPanelLayout);
        MainPanelLayout.setHorizontalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MainPanelLayout.createSequentialGroup()
                .addComponent(LeftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RightPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        MainPanelLayout.setVerticalGroup(
            MainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LeftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 485, Short.MAX_VALUE)
            .addComponent(RightPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(MainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(861, 524));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private int PortalSelected = 0;
    
    private void PublicPortalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PublicPortalMouseClicked
        PortalSelected = 0;
        setLblColor(PublicPortal);
        resetLblColor(EmployeePortal);
        resetLblColor(PolicePortal);
        resetLblColor(RescuePortal);
        LoginPanel.setVisible(false);
    }//GEN-LAST:event_PublicPortalMouseClicked

    private void EmployeePortalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmployeePortalMouseClicked
        PortalSelected = 1;
        setLblColor(EmployeePortal);
        resetLblColor(PublicPortal);
        resetLblColor(PolicePortal);
        resetLblColor(RescuePortal);
        LoginPanel.setVisible(true);
    }//GEN-LAST:event_EmployeePortalMouseClicked

    private void PolicePortalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PolicePortalMouseClicked
        PortalSelected = 2;
        setLblColor(PolicePortal);
        resetLblColor(PublicPortal);
        resetLblColor(EmployeePortal);
        resetLblColor(RescuePortal);
        LoginPanel.setVisible(true);
    }//GEN-LAST:event_PolicePortalMouseClicked

    private void RescuePortalMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RescuePortalMouseClicked
        PortalSelected = 3;
        setLblColor(RescuePortal);
        resetLblColor(PolicePortal);
        resetLblColor(EmployeePortal);
        resetLblColor(PublicPortal);
        LoginPanel.setVisible(true);
    }//GEN-LAST:event_RescuePortalMouseClicked

    private void LoginBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginBtnActionPerformed
        EmployeePortal empPortal = new EmployeePortal();
        empPortal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_LoginBtnActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainPage().setVisible(true);
            }
        });
    }
    
    private void setLblColor(JPanel jPanel){
        jPanel.setBackground(new Color(85,85,118));
    }
    
    private void resetLblColor(JPanel jPanel){
        jPanel.setBackground(new Color(59,40,97));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel EmployeePortal;
    private javax.swing.JTextField IDField;
    private javax.swing.JPanel LeftPanel;
    private javax.swing.JButton LoginBtn;
    private javax.swing.JLabel LoginHeader;
    private javax.swing.JPanel LoginPanel;
    private javax.swing.JPanel MainPanel;
    private javax.swing.JPasswordField PassField;
    private javax.swing.JPanel PolicePortal;
    private javax.swing.JPanel PublicPortal;
    private javax.swing.JPanel RescuePortal;
    private javax.swing.JPanel RightPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JSeparator jSeparator1;
    // End of variables declaration//GEN-END:variables
}
