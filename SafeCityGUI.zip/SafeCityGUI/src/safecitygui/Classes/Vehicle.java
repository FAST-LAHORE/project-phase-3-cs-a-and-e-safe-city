package safecitygui.Classes;

public class Vehicle {
    private String registrationNumber;
    private String ownerCNIC;
}