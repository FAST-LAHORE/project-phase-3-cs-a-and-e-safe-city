package safecitygui.Classes;

public enum CameraStatus {
    Active,
    InActive,
    Under_maintenance;
}