package safecitygui.Classes;

public class PoliceStation extends Organization {
    
}
