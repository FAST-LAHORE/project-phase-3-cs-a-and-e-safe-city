package safecitygui.Classes;

public class RescueStation extends Organization {
    
}
