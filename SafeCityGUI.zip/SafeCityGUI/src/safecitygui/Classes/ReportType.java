package safecitygui.Classes;

public enum ReportType {
    Lost_Person,
    Traffic_Violation,
    Crime,
    Accident,
    Fire,
    SuspectTrack,
    VehicleTrack;
}
